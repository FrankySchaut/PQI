__version__ = '0.2.0'
__description__ = 'Prompt Quality Index — Measure Meaning in Human-AI Dialogue'
